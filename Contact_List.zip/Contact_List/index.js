const express = require('express');
const port = 8000;
const path = require('path');

const app = express();


app.set('view engine','ejs');
app.set('views',path.join(__dirname,'views'));


app.get('/',function(req,res)
{
    return res.render('home');
    //console.log(__dirname);
   // res.send('cool it is running ');
});



app.listen(port,function(err){
    if(err)
    {
        console.log('error in running thr server',err);
    }

    console.log('My express server is running on port',port);

})