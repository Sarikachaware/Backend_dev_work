// Import required module

const readLine = require("readline");

//create interface
const Interface = readLine.createInterface
({
  input: process.stdin,
  output: process.stdout
});

//Actual code 
const Solution = () => 


{
  Interface.question("Enter first number: ", (num1) => {
    // Convert the user input to a number
    num1 = parseFloat(num1);

    // Check if num1 is a valid number
    if (isNaN(num1)) {
      console.log("Invalid input. Please enter a valid number.");
      Interface.close();
      return;
    }

    Interface.question("Enter second number: ", (num2) => {
      // Convert the user input to a number
      num2 = parseFloat(num2);

      // Check if num2 is a valid number
      if (isNaN(num2)) {
        console.log("Invalid input. Please enter a valid number.");
        Interface.close();
        return;
      }

      const maxNumber = Math.max(num1, num2);
      console.log("The maximum of the two numbers is: " + maxNumber);

      // Close the interface
      Interface.close();
    });
  });
}
  

Solution();
module.exports = Solution;
