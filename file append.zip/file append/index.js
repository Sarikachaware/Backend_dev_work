import http from "http";
import fs from "fs";

const server = http.createServer((req, res) => {
  //  Write your code here
  if (req.method == "POST") {
    let body = "";
    req.on("data", (chunk) => {
      body += chunk;
    });
    req.on("end", () => {
      fs.appendFileSync("data.txt", body);
      const info = fs.readFileSync("data.txt", { encoding: "utf-8" });
      console.log(info);
    });
  }
  res.end("data received");
});

export default server;


