const http = require('http');
const port = 8000;
const fs = require('fs');
//const server = http.createServer(requesthandler);
//server.listen(port,function(err)


function requesthandler(req,res)
{

    console.log(req.url);
    res.writeHead(200 ,{'Content-Type':'text/html'} );
   // res.end('go');
    fs.readFile('./index.html',function(err,data)
    {
        if (err)
        {
            console.log('error',err)
            return res.end('<h1>Error</h1>');
        }

        return res.end(data);
    });
}

const server = http.createServer(requesthandler);

server.listen(port,function(err)
{

    if(err)
    {
        console.log(err)
        return;

    }

    console.log('server is up and running on port',port);

});

/*const http = require('http');
const fs = require('fs');
const server = http.createServer((req,res)=>{
    const data = fs.readFileSync('./index.html').toString()
    res.end(data);
});
server.listen(8000,()=>{
    console.log('request send')
});
module.exports= server;*/
